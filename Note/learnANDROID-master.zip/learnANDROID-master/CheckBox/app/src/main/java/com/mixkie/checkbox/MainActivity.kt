package com.mixkie.checkbox

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pizza.setOnClickListener{
            if (pizza.isChecked) {
                Toast.makeText(this, "Pizza Selected", Toast.LENGTH_SHORT).show()
            }
        }

        chocolate.setOnClickListener{
            if (chocolate.isChecked) {
                Toast.makeText(this, "Chocolate Selected", Toast.LENGTH_SHORT).show()
            }
        }

        candy.setOnClickListener{
            if (candy.isChecked) {
                Toast.makeText(this, "Candy Selected", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
