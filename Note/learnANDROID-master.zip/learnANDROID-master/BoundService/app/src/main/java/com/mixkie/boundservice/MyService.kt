package com.mixkie.boundservice

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import java.util.*

class MyService : Service() {

    inner class MyBinder: Binder() {
        fun getServiceObject(): MyService {
            return this@MyService
        }
    }

    val binder: Binder = MyBinder()

    override fun onBind(intent: Intent): IBinder {
        return binder
    }

    fun getBread(): String {
        return "Bread"
    }

    fun getTime(): String {
        return Date().toString()
    }
}
