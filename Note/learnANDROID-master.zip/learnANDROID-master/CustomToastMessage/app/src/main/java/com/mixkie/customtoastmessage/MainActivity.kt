package com.mixkie.customtoastmessage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showToastButton.setOnClickListener {
            var view = layoutInflater.inflate(R.layout.custom_toast, null)

            var myToast = Toast(this)
            myToast.duration = Toast.LENGTH_SHORT
            myToast.setGravity(Gravity.BOTTOM, 0,  50)
            myToast.view = view

            myToast.show()
        }
    }
}
