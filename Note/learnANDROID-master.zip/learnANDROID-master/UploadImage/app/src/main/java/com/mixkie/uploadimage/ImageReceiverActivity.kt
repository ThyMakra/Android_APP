package com.mixkie.uploadimage

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_image_receiver.*

class ImageReceiverActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_receiver)

        Toast.makeText(this, "New Activity Loaded", Toast.LENGTH_SHORT).show()

        var imageURI: Uri? = intent.data
        selectedImage.setImageURI(imageURI)
    }
}
