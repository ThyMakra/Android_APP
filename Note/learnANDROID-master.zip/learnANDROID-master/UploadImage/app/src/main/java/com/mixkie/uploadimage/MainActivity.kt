package com.mixkie.uploadimage

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        upload_img_btn.setOnClickListener {
            var uploadImage = Intent(Intent.ACTION_GET_CONTENT)
            uploadImage.type = "image/*"
            startActivityForResult(uploadImage, 0)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 0 && resultCode == Activity.RESULT_OK && data != null) {
            val uri = data.data

            var newActivity = Intent(this, ImageReceiverActivity::class.java)
            newActivity.data = uri
            startActivity(newActivity)
        }
    }
}
