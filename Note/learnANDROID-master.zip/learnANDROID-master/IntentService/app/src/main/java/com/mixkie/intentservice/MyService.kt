package com.mixkie.intentservice

import android.app.IntentService
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import android.widget.Toast

class MyService() : IntentService("Daemon") {

    override fun onHandleIntent(p0: Intent?) {
        Log.d("Daemon", "We Are Doing Something")
        Log.d("Daemon", "We Are Doing Other Thing")
        Toast.makeText(this, "Task01", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task02", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task03", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task04", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task05", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task06", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task07", Toast.LENGTH_SHORT).show()
        Toast.makeText(this, "Task08", Toast.LENGTH_SHORT).show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("Daemon", "Service Started")
        Toast.makeText(this, "START", Toast.LENGTH_SHORT).show()
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        Log.d("Daemon", "Service Destroy")
    }
}