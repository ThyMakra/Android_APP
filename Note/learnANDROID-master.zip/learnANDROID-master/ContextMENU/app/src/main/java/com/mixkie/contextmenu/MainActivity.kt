package com.mixkie.contextmenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView
import kotlinx.android.synthetic.main.activity_main.*
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        registerForContextMenu(HelloWorld)
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        menuInflater.inflate(R.menu.my_menu, menu)
        super.onCreateContextMenu(menu, v, menuInfo)
    }

    fun showMenu(v: View?) {
        var popUpMenu = PopupMenu(this, v)
        popUpMenu.inflate(R.menu.my_menu2)
        popUpMenu.show()
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        var v = findViewById<TextView>(R.id.HelloWorld)

        when(item.itemId) {
            R.id.item1 -> {
                showMenu(v)
            } else -> {
                showMenu(v)
            }
        }
        return super.onContextItemSelected(item)
    }
}

