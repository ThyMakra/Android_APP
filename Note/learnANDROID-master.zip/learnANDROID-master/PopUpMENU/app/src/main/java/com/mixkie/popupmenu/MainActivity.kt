package com.mixkie.popupmenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn.setOnClickListener {
            var popUpMenu = PopupMenu(this, it)
            popUpMenu.inflate(R.menu.my_menu)
            popUpMenu.show()

            popUpMenu.setOnMenuItemClickListener { menuItem ->
                when(menuItem.itemId) {
                    R.id.item1 -> {
                        Toast.makeText(this, "Item1 Selected", Toast.LENGTH_SHORT).show()
                        true
                    }

                    R.id.item2 -> {
                        Toast.makeText(this, "Item2 Selected", Toast.LENGTH_SHORT).show()
                        true
                    }

                    R.id.item3 -> {
                        Toast.makeText(this, "Item3 Selected", Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> {
                        Toast.makeText(this, "Nothing Selected", Toast.LENGTH_SHORT).show()
                        false
                    }
                }
            }
        }
    }
}
