package com.mixkie.sharedpreference

import android.content.Context

class UserPreference(context: Context) {
    val FILENAME = "user_preference"

    val userPreference = context.getSharedPreferences(FILENAME, Context.MODE_PRIVATE)
    var editor = userPreference.edit()

    fun getData(dataName: String):Int {
        return userPreference.getInt(dataName, 0)
    }

    fun setData(dataName: String, dataValue: Int) {
        editor.putInt(dataName, dataValue)
        editor.apply()
    }
}