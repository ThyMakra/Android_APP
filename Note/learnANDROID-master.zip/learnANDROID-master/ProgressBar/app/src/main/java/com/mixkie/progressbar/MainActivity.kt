package com.mixkie.progressbar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        page.setOnClickListener {
            val v = if(progressBar.visibility == View.GONE) View.VISIBLE else View.GONE
            progressBar.visibility = v
        }
    }
}
