package com.mixkie.optionmenu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.my_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        var activityName: Class<*> = MainActivity::class.java

        when(item.itemId) {
            R.id.option1 -> {
                activityName = Option1Activity::class.java
                Toast.makeText(this, "Option1 Selected", Toast.LENGTH_SHORT).show()
            }

            R.id.option2 -> {
                activityName = Option2Activity::class.java
                Toast.makeText(this, "Option2 Selected", Toast.LENGTH_SHORT).show()
            }

            R.id.option3 -> {
                activityName = Option3Activity::class.java
                Toast.makeText(this, "Option3 Selected", Toast.LENGTH_SHORT).show()
            }
        }
        var intent = Intent(this, activityName)
        startActivity((intent))
        return super.onOptionsItemSelected(item)
    }
}
