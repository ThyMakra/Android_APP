package com.mixkie.optionmenu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Option3Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_option3)
    }
}
