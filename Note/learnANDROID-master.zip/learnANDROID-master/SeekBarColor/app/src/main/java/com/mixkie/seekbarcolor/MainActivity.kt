package com.mixkie.seekbarcolor

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        transparentSB.max = 255
        redSB.max = 255
        greenSB.max = 255
        blueSB.max = 255

        class CommonListener: SeekBar.OnSeekBarChangeListener{
            var transparent = 0
            var red = 0
            var green = 0
            var blue = 0

            override fun onProgressChanged(seekBar: SeekBar?, p1: Int, p2: Boolean) {
                when(seekBar?.id) {
                    R.id.transparentSB -> {transparent = p1}
                    R.id.redSB -> {red = p1}
                    R.id.greenSB -> {green = p1}
                    R.id.blueSB -> {blue = p1}
                }

                var sbColor = Color.argb(transparent, red, green, blue)
                myPage.setBackgroundColor(sbColor)

                var tColor = Color.argb(transparent, 255-red, 255-green, 255 - blue)
                textView.setTextColor(tColor)
                textView.text = "RGBA($red, $green, $blue, $transparent)"
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {
                // Do Nothing
            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
                // Do Nothing
            }
        }

        var commonListener = CommonListener()
        transparentSB.setOnSeekBarChangeListener(commonListener)
        redSB.setOnSeekBarChangeListener(commonListener)
        greenSB.setOnSeekBarChangeListener(commonListener)
        blueSB.setOnSeekBarChangeListener(commonListener)
    }
}
