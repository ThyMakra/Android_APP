package com.mixkie.asynctask

import android.content.Context
import android.os.AsyncTask
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView

class MyTask(ctx: Context, btn: Button, pb: ProgressBar, tv: TextView) : AsyncTask<Void, Int, String>() {

    var ctx: Context
    var btn: Button
    var pb: ProgressBar
    var tv: TextView

    init {
        this.ctx = ctx
        this.btn = btn
        this.pb = pb
        this.tv = tv
    }

    override fun onPreExecute() {
        tv.text = "Preparing for Downloading"
    }

    override fun doInBackground(vararg p0: Void?): String {
        for(i in 1..100 step 1){
            Thread.sleep(80)
            publishProgress(i)
        }

        return "Download Completed"
    }

    override fun onProgressUpdate(vararg values: Int?) {
        var progress = values[0]
        pb.progress = progress!!
        tv.text = "$progress/100 Downloaded"
    }

    override fun onPostExecute(result: String?) {
        tv.text = result
    }
}
